﻿# Script para importação das regras do firewall para utilização do MAP Toolkit - Windows 7 e Windows Server 2008 R2
netsh advfirewall import "c:\regras de firewall do MAP.wfw"