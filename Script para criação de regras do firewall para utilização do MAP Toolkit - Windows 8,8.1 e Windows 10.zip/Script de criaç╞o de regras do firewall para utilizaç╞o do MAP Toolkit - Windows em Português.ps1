﻿# Script de crição de regras do firewall para utlização do MAP Toolkit - Windows em Português

Enable-NetFirewallRule -DisplayGroup "Instrumentação de Gerenciamento do Windows (WMI)"

Enable-NetFirewallRule -DisplayGroup "Compartilhamento de Arquivo e Impressora"
