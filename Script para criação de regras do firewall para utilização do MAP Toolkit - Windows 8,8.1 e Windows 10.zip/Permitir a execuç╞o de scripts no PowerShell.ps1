﻿Get-ExecutionPolicy
Set-ExecutionPolicy Unrestricted