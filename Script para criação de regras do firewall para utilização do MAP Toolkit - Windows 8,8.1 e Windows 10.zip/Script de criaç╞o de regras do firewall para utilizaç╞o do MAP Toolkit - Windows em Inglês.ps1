﻿# Script de crição de regras do firewall para utlização do MAP Toolkit - Windows em Inglês

Enable-NetFirewallRule -DisplayGroup "Windows Management Instrumentation (WMI)"

Enable-NetFirewallRule -DisplayGroup "File and Printer Sharing"
